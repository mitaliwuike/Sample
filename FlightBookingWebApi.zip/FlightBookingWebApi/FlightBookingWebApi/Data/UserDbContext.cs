﻿using FlightBookingWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace FlightBookingWebApi.Data
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {

        }
        public DbSet<FBS_User> Users { get; set; }
        public DbSet<FBS_Flight_Master> fBS_Flight_Masters { get; set; }
        public DbSet<FBS_Booking_Transaction> FBS_Booking_Transactions { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FBS_User>().ToTable("FBS_User");
            modelBuilder.Entity<FBS_Flight_Master>().ToTable("FBS_Flight_Master");
            modelBuilder.Entity<FBS_Booking_Transaction>().ToTable("FBS_Booking_Transaction");

        }
    }
}
