﻿using System.Linq;
using System.Threading.Tasks;
using FlightBookingWebApi.Data;
using FlightBookingWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightBookingWebApi.Controllers
{
    /// <summary>
    /// Route for mapping using api controller attribute
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]

    //LoginController class is Inherited from ControllerBase Class.
    public class LoginController : ControllerBase
    {
        /// <summary>
        /// UserDbContext class will establish connection with database here
        /// </summary>
        private readonly UserDbContext context;
        public LoginController(UserDbContext _context)
        {
            context = _context;

        }
        /// <summary>
        /// Getusres method will return user details
        /// </summary>
        /// <returns></returns>
        [HttpGet("Users")]
        public IActionResult GetUsers()
        {
            var userDetails = context.Users.AsQueryable();
            return Ok(userDetails);
        }
        #region signup

        /// <summary>
        /// signup method is use to create user account
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost("signup")]
        public IActionResult SignUp([FromBody] FBS_User obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.Users.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "User add successfully"
                });
            }

        }
        #endregion signup

        /// <summary>
        /// This method is use to login
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost("Login")]
        public IActionResult Login([FromBody] FBS_User obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = context.Users.Where(a =>
                a.Username == obj.Username
                && a.Password == obj.Password).FirstOrDefault();
                if (user != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = " Logged in Successfully"
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "User Not Found"
                    });
                }
            }
        }
    }
}
